#!/usr/bin/env python
# coding: utf-8

# In[3]:


# Setup the Jupyter version of Dash
from jupyter_dash import JupyterDash

# Configure the necessary Python module imports for dashboard components
# Import Libraries
from jupyter_dash import JupyterDash
from dash import dcc, html, dash_table, Input, Output, State
import plotly.express as px
import dash_leaflet as dl
import base64
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os

# Import CRUD Module
from animals import AnimalShelter

# MongoDB Username and Password
username = "aacuser"
password = "newStrongPassword123"
db = AnimalShelter(username, password)

# Load data into DataFrame
df = pd.DataFrame.from_records(db.read({}))
df.drop(columns=['_id'], inplace=True)

# Encode Logo
image_filename = 'Grazioso Salvare Logo.png'
encoded_image = base64.b64encode(open(image_filename, 'rb').read())

# Setup App
app = JupyterDash(__name__)

# Layout
app.layout = html.Div([
    html.Center(html.H1('CS-340 Dashboard')),
    html.Center(
        html.Img(src='data:image/png;base64,{}'.format(encoded_image.decode()),
                 style={'width': '200px'})
    ),
    html.Hr(),

    # Filter Component
    html.Div([
        html.Label('Filter by Animal Type:'),
        dcc.RadioItems(
            id='filter-type',
            options=[
                {'label': 'Dogs', 'value': 'Dog'},
                {'label': 'Cats', 'value': 'Cat'},
                {'label': 'Rabbits', 'value': 'Rabbit'},
                {'label': 'All', 'value': 'All'}
            ],
            value='All',
            labelStyle={'display': 'inline-block', 'margin-right': '10px'}
        )
    ]),

    html.Hr(),

    # Data Table
    dash_table.DataTable(
        id='datatable-id',
        columns=[{"name": i, "id": i, "deletable": False, "selectable": True} for i in df.columns],
        data=df.to_dict('records'),
        row_selectable='single'
    ),

    html.Br(),
    html.Hr(),

    # Dashboard Layout (Chart + Map)
    html.Div(className='row',
             style={'display': 'flex'},
             children=[
                 html.Div(id='graph-id', className='col s12 m6'),
                 html.Div(id='map-id', className='col s12 m6')
             ])
])

# CALLBACK: Filter data by animal type
@app.callback(Output('datatable-id', 'data'),
              [Input('filter-type', 'value')])
def update_dashboard(filter_type):
    if filter_type == 'All':
        filtered = db.read({})
    else:
        filtered = db.read({"animal_type": filter_type})
    return pd.DataFrame.from_records(filtered).drop(columns=['_id']).to_dict('records')

# CALLBACK: Update Pie Chart
@app.callback(Output('graph-id', 'children'),
              [Input('datatable-id', 'derived_virtual_data')])
def update_graphs(viewData):
    if viewData is None:
        return html.Div()
    dff = pd.DataFrame.from_dict(viewData)
    fig = px.pie(dff, names='breed', title='Preferred Animals')
    return dcc.Graph(figure=fig)

# CALLBACK: Highlight selected columns
@app.callback(Output('datatable-id', 'style_data_conditional'),
              [Input('datatable-id', 'selected_columns')])
def update_styles(selected_columns):
    return [{
        'if': {'column_id': i},
        'background_color': '#D2F3FF'
    } for i in selected_columns]

# CALLBACK: Update Map Marker
@app.callback(Output('map-id', 'children'),
              [Input('datatable-id', 'derived_virtual_data'),
               Input('datatable-id', 'derived_virtual_selected_rows')])
def update_map(viewData, index):
    if viewData is None:
        return []
    dff = pd.DataFrame.from_dict(viewData)
    if index is None or len(index) == 0:
        return []
    row = index[0]
    return [
        dl.Map(style={'width': '1000px', 'height': '500px'}, center=[30.75, -97.48], zoom=10, children=[
            dl.TileLayer(id="base-layer-id"),
            dl.Marker(position=[dff.iloc[row,13], dff.iloc[row,14]], children=[
                dl.Tooltip(dff.iloc[row,4]),
                dl.Popup([
                    html.H1("Animal Name"),
                    html.P(dff.iloc[row,9])
                ])
            ])
        ])
    ]

# Run the app
app.run_server(debug=True)


# In[ ]:




